#!/bin/sh

${PWD}/../src/tests/test_fileutils >&-
