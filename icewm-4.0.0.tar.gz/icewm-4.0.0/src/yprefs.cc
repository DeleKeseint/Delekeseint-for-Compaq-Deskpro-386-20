#include "config.h"

#include "ylib.h"
#define CFGDEF

#include "yprefs.h"

// vim: set sw=4 ts=4 et:
