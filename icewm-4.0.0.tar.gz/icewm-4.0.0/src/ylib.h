#ifndef __YLIB_H
#define __YLIB_H

#include <X11/X.h>
#include <X11/Xlib.h>
#include <X11/extensions/Xfixes.h>
#include <X11/extensions/Xcomposite.h>
#include <X11/extensions/Xdamage.h>
#include <X11/extensions/Xrender.h>

#endif

// vim: set sw=4 ts=4 et:
